package com.mobeye.mobeye_testing_api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MobeyeTestingApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(MobeyeTestingApiApplication.class, args);
	}

}
